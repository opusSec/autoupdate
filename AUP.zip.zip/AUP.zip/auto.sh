#!/bin/bash 

x=0 
while [ $x = 0 ] 
do 
           clear 
           cat print.txt 
           sleep 1 
           echo "....................................................."
           echo "* Welcome! Type one number * (1-10)| and press Enter"  
           echo "....................................................." 
           echo "1.START AUTOUPDATE"
           echo "2.INSTALL KATOOLIN" 
           echo "3.FINGERPRINTING" 
           echo "4.SOCIAL BOX" 
           echo "5.RED-HAWK" 
           echo "6.THE LAZY SCRIPT" 
           echo "7.HIDDEN EYE" 
           echo "8.VEIL-EVASION" 
           echo "9.PROXYCHAIN CONFIG" 
           echo "10.EXIT" 
           sleep 3 
           read answer  

           case "$answer" in 
                  1) 
                  echo "Starting..."
                  x=1 
                  apt-get update 
                  apt-get upgrade 
                  apt-get install pip3 
                  apt-get install tor 
                  apt-get install git
                  ;; 
                  2) 
                  echo "Downloading Katoolin..." 
                  x=1  
                  echo "(Kali Linux Updates)"
                  git clone https://github.com/LionSec/katoolin.git && cp katoolin/katoolin.py /usr/bin/katoolin
                  chmod +x /usr/bin/katoolin 
                  echo "........."
                  echo "Completed!"
                  ;;
                  3) 
                  sleep 1
                  echo "Downloading Th3inspector..."
                  x=1 
                  echo "(Fingerprinting IP's)"
                  sleep 2
                  git clone https://github.com/Moham3dRiahi/Th3inspector.git 
                  cd Th3inspector
                  chmod +x install.sh && ./install.sh 
                 echo "............"
                  echo "It's done!" 
                  ;;
                  4)   
                  sleep 1
                  echo "Downloading Social-Box..."
                  x=1 
                  echo "(Brute force attacks)"
                  git clone https://github.com/Cyb0r9/SocialBox
                  ;;  
                  5)   
                  sleep 1 
                  echo "**USAGE**" 
                  cat RDH.txt 
                  sleep 60
                  echo "Downloading Red-Hawk"
                  x=1 
                  git clone https://github.com/Tuhinshubhra/RED_HAWK 
                  echo "Type: php rhawk.php To run..." 
                  sleep 5 
                  echo "Installation completed!"
                  ;;
                  6)   
                  sleep 1
                  echo "Downloading..."
                  x=1 
                  git clone https://github.com/arismelachroinos/lscript 
                  echo "Downloaded starting with install..." 
                  cd lscript 
                  chmod +x install.sh 
                  ./install.sh 
                  echo "COngratulations; Usage:open terminal" 
                  echo "Type:'l' to run" 
                  sleep 5
                  ;;
                  7)   
                  sleep 1
                  echo "Downloading..."
                  x=1 
                  git clone https://github.com/DarkSecDevelopers/HiddenEye 
                  echo "Okay! It's done | Usage: python3 HiddenEye.py" 
                  sleep 5
                  ;;
                  8)   
                  sleep 1
                  echo "GET Veil-Evasion..."
                  x=1 
                  git clone https://github.com/Veil-Framework/Veil-Evasion.git  
                  cat vlf.txt 
                  sleep 6
                  cd Veil-Evasion/ 
                  cd setup 
                  setup.sh -c 
                  sleep 1 
                  ;;
                  9)
                  apt-get install tor   
                  sleep 1
                  echo "Checking Tor Status..." 
                  service tor status 
                  sleep 7 
                  x=1 
                  ;;
                  10)
                  x=1
                  echo "Exiting..." 
                  sleep 2
                  ;;
                  *) 
                  clear 
                  echo "That is not an option" 
                  sleep 3 
                  ;; 
        esac 

done 
