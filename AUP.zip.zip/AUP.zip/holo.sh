#!bin/bash
sudo -i   
apt-get install cmatrix 
konsole -e command
cmatrix -f -l -u 5 -C green 


